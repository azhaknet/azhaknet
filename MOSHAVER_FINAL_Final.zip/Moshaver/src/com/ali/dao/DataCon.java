package com.ali.dao;

import java.math.BigInteger;
import java.sql.*;
import java.util.Date;

public class DataCon {

	String sql;
	String url="jdbc:mysql://localhost:3306/moshaver";
	String user="Ali";
	String password="";
	String m="";
	int coId;
	String wlt;

	public int getCoId() {
		return this.coId;
	}
	public String getWlt() {
		return this.wlt;
	}

	public boolean checkAdmin(String un,String p) {
		sql="select * FROM moshaver.moshaver where UserName=? and Pass=?  and MemberShip_FK=1";


		try {
			Class.forName("com.mysql.cj.jdbc.Driver");
			Connection con= DriverManager.getConnection(url, user, password);
			PreparedStatement ps=con.prepareStatement(sql);
			ps.setString(1, un);
			ps.setString(2, p);
			ResultSet rs=ps.executeQuery();
			if (rs.next()) {
				wlt=rs.getString(12);
				return true;
			}
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}

		return false;
	}


	public boolean checkUser(String un,String p) {
		sql="select * FROM moshaver.users where UserName=? and Pass=?";


		try {
			Class.forName("com.mysql.cj.jdbc.Driver");
			Connection con= DriverManager.getConnection(url, user, password);
			PreparedStatement ps=con.prepareStatement(sql);
			ps.setString(1, un);
			ps.setString(2, p);
			ResultSet rs=ps.executeQuery();
			if (rs.next()) {
				coId=rs.getInt(1);
				wlt=rs.getString(9);
				return true;
			}
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}

		return false;
	}

	public int getMoshaver() {
		sql="select * FROM moshaver.moshaver";


		try {
			Class.forName("com.mysql.cj.jdbc.Driver");
			Connection con= DriverManager.getConnection(url, user, password);
			PreparedStatement ps=con.prepareStatement(sql);
			ResultSet rs=ps.executeQuery();
			if (rs.next()) {
				coId=rs.getInt(1);
				if (rs.getInt(3)==2) 
					return 1;
				else if(rs.getInt(3)==3) 
					return 0;
			}
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}

		return -1;
	}

	public int checkMoshaver(String un,String p) {
		sql="select * FROM moshaver.moshaver where UserName=? and Pass=? ";


		try {
			Class.forName("com.mysql.cj.jdbc.Driver");
			Connection con= DriverManager.getConnection(url, user, password);
			PreparedStatement ps=con.prepareStatement(sql);
			ps.setString(1, un);
			ps.setString(2, p);
			ResultSet rs=ps.executeQuery();
			if (rs.next()) {
				coId=rs.getInt(1);
				wlt=rs.getString(12);
				if (rs.getInt(3)==2) 
					return 1;
				else if(rs.getInt(3)==3) 
					return 0;
			}
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}

		return -1;
	}

	public boolean approvalMoshaver(int t,int id) {
		//insert into moshaver values(10,5,6,'ali','karimi',1656,'a@a.com','a','k',123,52);
		sql="update moshaver.moshaver set MemberShip_FK=? where ID=?";
		try {
			Class.forName("com.mysql.cj.jdbc.Driver");
			Connection con= DriverManager.getConnection(url, user, password);
			PreparedStatement ps=con.prepareStatement(sql);
			ps.setInt(1, t);
			ps.setInt(2, id);
			ps.executeUpdate();
			return true;
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}

		return false;
	}
	public boolean unapprovalMoshaver(int id) {
		//insert into moshaver values(10,5,6,'ali','karimi',1656,'a@a.com','a','k',123,52);
		sql="DELETE FROM moshaver.moshaver WHERE (ID = ?)";
		try {
			Class.forName("com.mysql.cj.jdbc.Driver");
			Connection con= DriverManager.getConnection(url, user, password);
			PreparedStatement ps=con.prepareStatement(sql);
			ps.setInt(1, id);
			ps.executeUpdate();
			return true;
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}

		return false;
	}
	public boolean delId( String g,int id) {
		//insert into moshaver values(10,5,6,'ali','karimi',1656,'a@a.com','a','k',123,52);
		Connection con=null;
		sql="DELETE FROM "+g+" WHERE (ID = ?)";
		try {
			Class.forName("com.mysql.cj.jdbc.Driver");
			con= DriverManager.getConnection(url, user, password);
			PreparedStatement ps=con.prepareStatement(sql);
			ps.setInt(1, id);
			if (g.equals("moshaver.darkhast")) {
				String sql1="DELETE FROM moshaver.respond where Darkhast_FK=?";
				PreparedStatement ps2=con.prepareStatement(sql1);
				ps2.setInt(1, id);
				ps2.executeUpdate();			
			}
			else if (g.equals("moshaver.respond")) {
				upFDarkhast(1, getResDar(id));
			}
			ps.executeUpdate();
			return true;
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}finally {
			if(con!=null)
				try {
					con.close();
				} catch (SQLException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
		}



		return false;
	}


	public boolean addMoshaver(int gr,String fn ,String ln,String Tl,String em,String un,String p,String md,double sc) {
		//insert into moshaver values(10,5,6,'ali','karimi',1656,'a@a.com','a','k',123,52);
		sql="insert into moshaver.moshaver values(?,?,?,?,?,?,?,?,?,?,?,0)";


		try {
			Class.forName("com.mysql.cj.jdbc.Driver");
			Connection con= DriverManager.getConnection(url, user, password);
			PreparedStatement ps=con.prepareStatement(sql);
			ps.setInt(1, maxIdGroup("moshaver.moshaver")+1);
			ps.setInt(2, gr);
			ps.setInt(3, 3);
			ps.setString(4, fn);
			ps.setString(5, ln);
			ps.setString(6, Tl);
			ps.setString(7, em);
			ps.setString(8, un);
			ps.setString(9, p);
			ps.setString(10, md);
			ps.setDouble(11, sc);
			ps.executeUpdate();
			return true;
		}catch (SQLIntegrityConstraintViolationException e) {
			m="این نام کاربری قبلا انتخاب شده است.";
		}
		catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}

		return false;
	}

	public String msg() {
		return this.m;
	}
	public boolean updateMoshaver(int id,String fn ,String ln,String Tl,String em,String pss,String md) {
		//insert into moshaver values(10,5,6,'ali','karimi',1656,'a@a.com','a','k',123,52);
		if (pss.equals("")) {
			sql="UPDATE moshaver.moshaver SET FName=?,LName=?,Tell=?,Email=?,Madrak=? WHERE ID=?";

		}else {
			sql="UPDATE moshaver.moshaver SET FName=?,LName=?,Tell=?,Email=?,Madrak=?,Pass=? WHERE ID=?";
		}

		Connection con=null;
		try {
			Class.forName("com.mysql.cj.jdbc.Driver");
			con= DriverManager.getConnection(url, user, password);
			PreparedStatement ps=con.prepareStatement(sql);
			ps.setString(1, fn);
			ps.setString(2, ln);
			ps.setString(3, Tl);
			ps.setString(4, em);
			ps.setString(5, md);
			if (pss.equals("")) {
				ps.setInt(6, id);
			}
			else {
				ps.setString(6, pss);
				ps.setInt(7, id);
			}

			ps.executeUpdate();
			return true;
		}catch (SQLIntegrityConstraintViolationException e) {
			m="این نام کاربری قبلا انتخاب شده است.";
		}
		catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}finally {
			if(con!=null)
				try {
					con.close();
				} catch (SQLException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
		}

		return false;
	}

	public boolean addUser(String un,String p,String fn ,String ln,String tell,String em,int age) {
		sql="insert into moshaver.users values(?,?,?,?,?,?,?,?,0)";


		try {
			Class.forName("com.mysql.cj.jdbc.Driver");
			Connection con= DriverManager.getConnection(url, user, password);
			PreparedStatement ps=con.prepareStatement(sql);
			ps.setInt(1, maxIdGroup("moshaver.users")+1);
			ps.setString(2, un);
			ps.setString(3, p);
			ps.setString(4, fn);
			ps.setString(5, ln);
			ps.setString(6, tell);
			ps.setString(7, em);
			ps.setInt(8, age);
			ps.executeUpdate();
			return true;
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}

		return false;
	}
	public boolean updateUser(int id,String fn ,String ln,String Tl,String em,String pss) {
		//insert into moshaver values(10,5,6,'ali','karimi',1656,'a@a.com','a','k',123,52);
		if (pss.equals("")) {
			sql="UPDATE moshaver.users SET FName=?,LName=?,Tell=?,Email=? WHERE ID=?";

		}else {
			sql="UPDATE moshaver.users SET FName=?,LName=?,Tell=?,Email=?,Pass=? WHERE ID=?";
		}

		Connection con=null;
		try {
			Class.forName("com.mysql.cj.jdbc.Driver");
			con= DriverManager.getConnection(url, user, password);
			PreparedStatement ps=con.prepareStatement(sql);
			ps.setString(1, fn);
			ps.setString(2, ln);
			ps.setString(3, Tl);
			ps.setString(4, em);
			if (pss.equals("")) {
				ps.setInt(5, id);
			}
			else {
				ps.setString(5, pss);
				ps.setInt(6, id);
			}

			ps.executeUpdate();
			return true;
		}catch (SQLIntegrityConstraintViolationException e) {
			m="این نام کاربری قبلا انتخاب شده است.";
		}
		catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}finally {
			if(con!=null)
				try {
					con.close();
				} catch (SQLException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
		}

		return false;
	}


	public boolean addGroup(String name) {
		sql="INSERT INTO moshaver.groups VALUES (?, ?)";

		try {
			Class.forName("com.mysql.cj.jdbc.Driver");
			Connection con= DriverManager.getConnection(url, user, password);
			PreparedStatement ps=con.prepareStatement(sql);
			ps.setInt(1, maxIdGroup("moshaver.groups")+1);
			ps.setString(2, name);
			ps.executeUpdate();
			return true;
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}

		return false;
	}

	public boolean addSGroup(int group,String name) {
		sql="INSERT INTO moshaver.subgroups VALUES (?, ?, ?)";

		try {
			Class.forName("com.mysql.cj.jdbc.Driver");
			Connection con= DriverManager.getConnection(url, user, password);
			PreparedStatement ps=con.prepareStatement(sql);
			ps.setInt(1, maxIdGroup("moshaver.subgroups")+1);
			ps.setInt(2, group);
			ps.setString(3, name);
			ps.executeUpdate();
			return true;
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}

		return false;
	}
	public boolean addDarkhast(int userId,int moshaverId,String title,String text,int sgroup) {
		sql="INSERT INTO moshaver.darkhast (ID, Groups_FK, SubGroups_FK, Users_FK, Moshaver_FK, Date, Title, State, Content) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)";
		Connection con=null;
		java.sql.Date dt=new java.sql.Date(new Date().getTime());
		try {
			Class.forName("com.mysql.cj.jdbc.Driver");
			con= DriverManager.getConnection(url, user, password);
			PreparedStatement ps=con.prepareStatement(sql);
			ps.setInt(1, maxIdGroup("moshaver.darkhast")+1);
			ps.setInt(2, getGrp(sgroup));
			ps.setInt(3, sgroup);
			ps.setInt(4, userId);
			ps.setInt(5, moshaverId);
			ps.setDate(6, dt);
			ps.setString(7, title);
			ps.setInt(8, 1);
			ps.setString(9, text);
			ps.executeUpdate();
			return true;
		}catch (SQLIntegrityConstraintViolationException e) {
			m="این نام کاربری قبلا انتخاب شده است.";
		}
		catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}finally {
			if(con!=null)
				try {
					con.close();
				} catch (SQLException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
		}

		return false;
	}

	public boolean addPasokh(int moshaverId,int Did,int type,int cost, String text) {
		sql="INSERT INTO moshaver.respond (ID, Moshaver_FK, Darkhast_FK, Date, Respond, Cost, Type_FK) VALUES (?,?,?,?,?,?,?)";

		java.sql.Date dt=new java.sql.Date(new Date().getTime());
		Connection con=null;
		try {
			Class.forName("com.mysql.cj.jdbc.Driver");
			con= DriverManager.getConnection(url, user, password);
			PreparedStatement ps=con.prepareStatement(sql);
			ps.setInt(1, maxIdGroup("moshaver.respond")+1);
			ps.setInt(2, moshaverId);
			ps.setInt(3, Did);
			ps.setDate(4, dt);
			ps.setString(5, text);
			ps.setInt(6, cost);
			ps.setInt(7, type);
			ps.executeUpdate();
			if (type==1) {
				if(upFDarkhast(4,Did))
					return true;

			}else {
				if(upFDarkhast(2,Did))
					return true;
			}

			return true;

		}catch (SQLIntegrityConstraintViolationException e) {
			m="این نام کاربری قبلا انتخاب شده است.";
		}
		catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}finally {
			if(con!=null)
				try {
					con.close();
				} catch (SQLException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
		}

		return false;
	}
	
	public int getDar(int Uid) {
		sql="select * FROM moshaver.darkhast where Users_FK=?";


		try {
			Class.forName("com.mysql.cj.jdbc.Driver");
			Connection con= DriverManager.getConnection(url, user, password);
			PreparedStatement ps=con.prepareStatement(sql);
			ps.setInt(1, Uid);
			ResultSet rs=ps.executeQuery();
			int n = 0;
			while (rs.next()) {
				n++;
			}
			return n;
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}

		return 0;
	}
	

	public boolean cloneRes(int userId,int darkhastId,int resId) {
		
		sql="SELECT * FROM moshaver.darkhast where ID=?";
		Connection con1=null;
		int group=0,sgroup = 0,moshaverId = 0,state=0;
		String title = null,text=null;
		try {
			Class.forName("com.mysql.cj.jdbc.Driver");
			con1= DriverManager.getConnection(url, user, password);
			PreparedStatement ps=con1.prepareStatement(sql);
			ps.setInt(1, darkhastId);
			ResultSet rs=ps.executeQuery();
			while (rs.next()) {
				group=rs.getInt(2);
				sgroup=rs.getInt(3);
				moshaverId=rs.getInt(5);
				title=rs.getString(7);
				state=2;
				text=rs.getString(9);
			}
		}catch (SQLIntegrityConstraintViolationException e) {
			m="این نام کاربری قبلا انتخاب شده است.";
		}
		catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}finally {
			if(con1!=null)
				try {
					con1.close();
				} catch (SQLException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
		}
		
		
		sql="SELECT * FROM moshaver.respond where ID=?";
		Connection con3=null;
		int cost=0,typ=0;
		String resTxt = null;
		try {
			Class.forName("com.mysql.cj.jdbc.Driver");
			con3= DriverManager.getConnection(url, user, password);
			PreparedStatement ps=con3.prepareStatement(sql);
			ps.setInt(1, resId);
			ResultSet rs=ps.executeQuery();
			while (rs.next()) {
				cost=rs.getInt(6);
				typ=rs.getInt(7);
				resTxt=rs.getString(5);
			}
		}catch (SQLIntegrityConstraintViolationException e) {
			m="این نام کاربری قبلا انتخاب شده است.";
		}
		catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}finally {
			if(con3!=null)
				try {
					con3.close();
				} catch (SQLException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
		}
		
		
		sql="INSERT INTO moshaver.darkhast (ID, Groups_FK, SubGroups_FK, Users_FK, Moshaver_FK, Date, Title, State, Content) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)";
		Connection con=null;
		java.sql.Date dt=new java.sql.Date(new Date().getTime());
		try {
			Class.forName("com.mysql.cj.jdbc.Driver");
			con= DriverManager.getConnection(url, user, password);
			PreparedStatement ps=con.prepareStatement(sql);
			ps.setInt(1, maxIdGroup("moshaver.darkhast")+1);
			ps.setInt(2, group);
			ps.setInt(3, sgroup);
			ps.setInt(4, userId);
			ps.setInt(5, moshaverId);
			ps.setDate(6, dt);
			ps.setString(7, title);
			ps.setInt(8, state);
			ps.setString(9, text);
			ps.executeUpdate();
		}catch (SQLIntegrityConstraintViolationException e) {
			m="این نام کاربری قبلا انتخاب شده است.";
		}
		catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}finally {
			if(con!=null)
				try {
					con.close();
				} catch (SQLException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
		}
		sql="INSERT INTO moshaver.respond (ID, Moshaver_FK, Darkhast_FK, Date, Respond, Cost, Type_FK) VALUES (?,?,?,?,?,?,?)";
		Connection con2=null;
		try {
			Class.forName("com.mysql.cj.jdbc.Driver");
			con2= DriverManager.getConnection(url, user, password);
			PreparedStatement ps=con2.prepareStatement(sql);
			ps.setInt(1, maxIdGroup("moshaver.respond")+1);
			ps.setInt(2, moshaverId);
			ps.setInt(3, maxIdGroup("moshaver.darkhast"));
			ps.setDate(4, dt);
			ps.setString(5, resTxt);
			ps.setInt(6, cost);
			ps.setInt(7, typ);
			ps.executeUpdate();
			return true;

		}catch (SQLIntegrityConstraintViolationException e) {
			m="این نام کاربری قبلا انتخاب شده است.";
		}
		catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}finally {
			if(con2!=null)
				try {
					con2.close();
				} catch (SQLException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
		}

		return false;
	}
	
	
	public int getmDar(int mid) {
		sql="select * FROM moshaver.darkhast where State=1 and Moshaver_FK=?";


		try {
			Class.forName("com.mysql.cj.jdbc.Driver");
			Connection con= DriverManager.getConnection(url, user, password);
			PreparedStatement ps=con.prepareStatement(sql);
			ps.setInt(1, mid);
			ResultSet rs=ps.executeQuery();
			int n = 0;
			while (rs.next()) {
				n++;
			}
			return n;
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}

		return 0;
	}


	public int getRes(int Mid) {
		sql="select * FROM moshaver.respond where Moshaver_FK=?";

		Connection con=null;
		try {
			Class.forName("com.mysql.cj.jdbc.Driver");
			con= DriverManager.getConnection(url, user, password);
			PreparedStatement ps=con.prepareStatement(sql);
			ps.setInt(1, Mid);
			ResultSet rs=ps.executeQuery();
			int n = 0;
			while (rs.next()) {
				n++;
			}
			return n;
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}finally {
			if(con!=null)
				try {
					con.close();
				} catch (SQLException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
		}

		return 0;
	}
	
	public int getResDar(int pid) {
		sql="select * FROM moshaver.respond where ID=?";
		Connection con=null;

		try {
			Class.forName("com.mysql.cj.jdbc.Driver");
			con= DriverManager.getConnection(url, user, password);
			PreparedStatement ps=con.prepareStatement(sql);
			ps.setInt(1, pid);
			ResultSet rs=ps.executeQuery();
			
			if (rs.next()) {
				return rs.getInt(3);
			}
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}finally {
			if(con!=null)
				try {
					con.close();
				} catch (SQLException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
		}

		return 0;
	}
	public String getTRes(int pid) {
		sql="select * FROM moshaver.respond where ID=?";
		Connection con=null;

		try {
			Class.forName("com.mysql.cj.jdbc.Driver");
			con= DriverManager.getConnection(url, user, password);
			PreparedStatement ps=con.prepareStatement(sql);
			ps.setInt(1, pid);
			ResultSet rs=ps.executeQuery();
			String n = "";
			while (rs.next()) {
				n=rs.getString(5);
			}
			return n;
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}finally {
			if(con!=null)
				try {
					con.close();
				} catch (SQLException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
		}

		return "";
	}
	
	public boolean setSRes(int pid) {
		sql="select * FROM moshaver.respond where ID=?";
		Connection con=null;

		try {
			Class.forName("com.mysql.cj.jdbc.Driver");
			con= DriverManager.getConnection(url, user, password);
			PreparedStatement ps=con.prepareStatement(sql);
			ps.setInt(1, pid);
			ResultSet rs=ps.executeQuery();
			if (rs.next()) {
				return upFDarkhast(5, rs.getInt(3));
			}
			else {
			return false;
			}
			
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}finally {
			if(con!=null)
				try {
					con.close();
				} catch (SQLException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
		}

		return false;
	}

	public boolean upMScore(int Moshaver,int sc2) {
		sql="UPDATE moshaver.moshaver SET Score = ? WHERE (ID = ?)";

		try {
			Class.forName("com.mysql.cj.jdbc.Driver");
			Connection con= DriverManager.getConnection(url, user, password);
			PreparedStatement ps=con.prepareStatement(sql);
			int sc1=(int)(getScore(Moshaver)*100);
			int scorei=(sc1+sc2)/2;
			double score=(double)(scorei)/100;
			ps.setDouble(1, score);
			ps.setInt(2, Moshaver);
			ps.executeUpdate();
			return true;
		}catch (SQLIntegrityConstraintViolationException e) {
			m="این نام کاربری قبلا انتخاب شده است.";
		}
		catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}

		return false;
	}

	public boolean edFPasokh(int pid,String txt) {
		sql="UPDATE moshaver.respond SET Respond = ? WHERE (ID = ?)";
		Connection con=null;

		try {
			Class.forName("com.mysql.cj.jdbc.Driver");
			con= DriverManager.getConnection(url, user, password);
			PreparedStatement ps=con.prepareStatement(sql);
			ps.setString(1, txt);
			ps.setInt(2, pid);
			ps.executeUpdate();
			return true;
		}catch (SQLIntegrityConstraintViolationException e) {
			m="این نام کاربری قبلا انتخاب شده است.";
		}
		catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}finally {
			if(con!=null)
				try {
					con.close();
				} catch (SQLException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
		}

		return false;
	}
	
	public boolean chargeWallet(int uid, String pm) {
		sql="UPDATE moshaver.users SET Wallet = ? WHERE (ID = ?)";
		Connection con=null;
		
		try {
			Class.forName("com.mysql.cj.jdbc.Driver");
			con= DriverManager.getConnection(url, user, password);
			PreparedStatement ps=con.prepareStatement(sql);
			ps.setString(1, pm);
			ps.setInt(2, uid);
			ps.executeUpdate();
			return true;
		}catch (SQLIntegrityConstraintViolationException e) {
			m="این نام کاربری قبلا انتخاب شده است.";
		}
		catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}finally {
			if(con!=null)
				try {
					con.close();
				} catch (SQLException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
		}

		return false;
	}
	
	public boolean getpyWlt(int mid, String pm) {
		sql="UPDATE moshaver.moshaver SET Wallet = ? WHERE (ID = ?)";
		Connection con=null;
		
		try {
			Class.forName("com.mysql.cj.jdbc.Driver");
			con= DriverManager.getConnection(url, user, password);
			PreparedStatement ps=con.prepareStatement(sql);
			ps.setString(1, pm);
			ps.setInt(2, mid);
			ps.executeUpdate();
			return true;
		}catch (SQLIntegrityConstraintViolationException e) {
			m="این نام کاربری قبلا انتخاب شده است.";
		}
		catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}finally {
			if(con!=null)
				try {
					con.close();
				} catch (SQLException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
		}

		return false;
	}
	
	public boolean dechargeWallet(int mid,String pm1) {
		sql="UPDATE moshaver.moshaver SET Wallet = ? WHERE (ID = ?)";
		Connection con=null;
		
		try {
			Class.forName("com.mysql.cj.jdbc.Driver");
			con= DriverManager.getConnection(url, user, password);
			PreparedStatement ps=con.prepareStatement(sql);
			ps.setString(1, pm1);
			ps.setInt(2, mid);
			ps.executeUpdate();
			return true;
		}catch (SQLIntegrityConstraintViolationException e) {
			m="این نام کاربری قبلا انتخاب شده است.";
		}
		catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}finally {
			if(con!=null)
				try {
					con.close();
				} catch (SQLException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
		}

		return false;
	}
	
	public boolean payCPasokh(int pid,int cost) {
		
		sql="UPDATE moshaver.respond SET Cost = ? WHERE (ID = ?)";
		Connection con=null;
		try {
			Class.forName("com.mysql.cj.jdbc.Driver");
			con= DriverManager.getConnection(url, user, password);
			PreparedStatement ps=con.prepareStatement(sql);
			ps.setInt(1,cost*-1);
			ps.setInt(2, pid);
			ps.executeUpdate();
			return true;
		}catch (SQLIntegrityConstraintViolationException e) {
			m="این نام کاربری قبلا انتخاب شده است.";
		}
		catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}finally {
			if(con!=null)
				try {
					con.close();
				} catch (SQLException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
		}

		return false;
	}

	public int getMGroup(int Mid) {
		sql="select * FROM moshaver.moshaver where ID=?";

		Connection con=null;
		try {
			Class.forName("com.mysql.cj.jdbc.Driver");
			con= DriverManager.getConnection(url, user, password);
			PreparedStatement ps=con.prepareStatement(sql);
			ps.setInt(1, Mid);
			ResultSet rs=ps.executeQuery();
			if (rs.next()) {
				return rs.getInt(2);
			}
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}finally {
			if(con!=null)
				try {
					con.close();
				} catch (SQLException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
		}

		return -1;
	}

	public double getScore(int Mid) {
		sql="select * FROM moshaver.moshaver where ID=?";

		Connection con=null;
		try {
			Class.forName("com.mysql.cj.jdbc.Driver");
			con= DriverManager.getConnection(url, user, password);
			PreparedStatement ps=con.prepareStatement(sql);
			ps.setInt(1, Mid);
			ResultSet rs=ps.executeQuery();
			if (rs.next()) {
				return rs.getDouble(11);
			}
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}finally {
			if(con!=null)
				try {
					con.close();
				} catch (SQLException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
		}

		return -1;
	}
	public String getnWltu(int uid,String nn) {
		sql="select * FROM moshaver.users where ID=?";
		
		Connection con=null;
		try {
			Class.forName("com.mysql.cj.jdbc.Driver");
			con= DriverManager.getConnection(url, user, password);
			PreparedStatement ps=con.prepareStatement(sql);
			ps.setInt(1, uid);
			ResultSet rs=ps.executeQuery();
			if (rs.next()) {

				long m1=Long.parseLong(rs.getString(9));
				long m2=Long.parseLong(nn);
				
				return m1+m2+"";
			}
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}finally {
			if(con!=null)
				try {
					con.close();
				} catch (SQLException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
		}

		return "0";
	}
	public String getnWltm(int mid,String nn) {
		sql="select * FROM moshaver.moshaver where ID=?";
		
		Connection con=null;
		try {
			Class.forName("com.mysql.cj.jdbc.Driver");
			con= DriverManager.getConnection(url, user, password);
			PreparedStatement ps=con.prepareStatement(sql);
			ps.setInt(1, mid);
			ResultSet rs=ps.executeQuery();
			if (rs.next()) {

				long m1=Long.parseLong(rs.getString(12));
				long m2=Long.parseLong(nn);
				
				return m1+m2+"";
			}
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}finally {
			if(con!=null)
				try {
					con.close();
				} catch (SQLException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
		}

		return "0";
	}
	
	public boolean getpyWlt(int uid,String nn,int mid) {
		sql="select * FROM moshaver.users where ID=?";
		
		Connection con=null;
		try {
			Class.forName("com.mysql.cj.jdbc.Driver");
			con= DriverManager.getConnection(url, user, password);
			PreparedStatement ps=con.prepareStatement(sql);
			ps.setInt(1, uid);
			ResultSet rs=ps.executeQuery();
			if (rs.next()) {
				if (nn.charAt(0)=='-') {
					nn=nn.substring(1);
				}
				long m1=Long.parseLong(getnWltu(uid, '-'+nn));
				
				if (m1>=0) {
					wlt=m1+"";
					chargeWallet(uid, m1+"");
					String mmm=getnWltm(mid, nn);
					dechargeWallet(mid, mmm);
					return true;
					
				}else {
					
					m="موجودی شما کافی نیست.";
					return false;
				}
				
			}
			
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}finally {
			if(con!=null)
				try {
					con.close();
				} catch (SQLException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
		}

		return false;
	}
	public String getMNumber(int Mid)  {
		sql="select * FROM moshaver.moshaver where ID=?";

		Connection con=null;
		try {
			Class.forName("com.mysql.cj.jdbc.Driver");
			con= DriverManager.getConnection(url, user, password);
			PreparedStatement ps=con.prepareStatement(sql);
			ps.setInt(1, Mid);
			ResultSet rs=ps.executeQuery();
			if (rs.next()) {
				return rs.getString(6);
			}
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}finally {
			if(con!=null)
				try {
					con.close();
				} catch (SQLException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
		}

		return "ERROR!";
	}
	public String getMEmail(int Mid) {
		sql="select * FROM moshaver.moshaver where ID=?";

		Connection con=null;
		try {
			Class.forName("com.mysql.cj.jdbc.Driver");
			con= DriverManager.getConnection(url, user, password);
			PreparedStatement ps=con.prepareStatement(sql);
			ps.setInt(1, Mid);
			ResultSet rs=ps.executeQuery();
			if (rs.next()) {
				return rs.getString(7);
			}
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}finally {
			if(con!=null)
				try {
					con.close();
				} catch (SQLException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
		}

		return "ERROR!";
	}

	public boolean cancelPasokh(int Pid) {
		sql="UPDATE moshaver.respond SET Type_FK = ? WHERE (ID = ?)";
		Connection con=null;
		try {
			Class.forName("com.mysql.cj.jdbc.Driver");
			con= DriverManager.getConnection(url, user, password);
			PreparedStatement ps=con.prepareStatement(sql);
			ps.setInt(1, 4);
			ps.setInt(2, Pid);
			ps.executeUpdate();
			return true;
		}catch (SQLIntegrityConstraintViolationException e) {
			m="این نام کاربری قبلا انتخاب شده است.";
		}
		catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}finally {
			if(con!=null)
				try {
					con.close();
				} catch (SQLException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
		}

		return false;
	}

	public boolean upFDarkhast(int st,int Did) {
		sql="UPDATE moshaver.darkhast SET State = ? WHERE (ID = ?)";
		Connection con=null;
		try {
			Class.forName("com.mysql.cj.jdbc.Driver");
			con= DriverManager.getConnection(url, user, password);
			PreparedStatement ps=con.prepareStatement(sql);
			ps.setInt(1, st);
			ps.setInt(2, Did);
			ps.executeUpdate();
			return true;
		}catch (SQLIntegrityConstraintViolationException e) {
			m="این نام کاربری قبلا انتخاب شده است.";
		}
		catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}finally {
			if(con!=null)
				try {
					con.close();
				} catch (SQLException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
		}

		return false;
	}

	public boolean addFDarkhast(int userId,String title,String text,int sgroup) {
		sql="INSERT INTO moshaver.darkhast (ID, Groups_FK, SubGroups_FK, Users_FK, Date, Title, State, Content) VALUES (?, ?, ?, ?, ?, ?, ?, ?)";
		Connection con=null;
		java.sql.Date dt=new java.sql.Date(new Date().getTime());
		try {
			Class.forName("com.mysql.cj.jdbc.Driver");
			con= DriverManager.getConnection(url, user, password);
			PreparedStatement ps=con.prepareStatement(sql);
			ps.setInt(1, maxIdGroup("moshaver.darkhast")+1);
			ps.setInt(2, getGrp(sgroup));
			ps.setInt(3, sgroup);
			ps.setInt(4, userId);
			ps.setDate(5, dt);
			ps.setString(6, title);
			ps.setInt(7, 3);
			ps.setString(8, text);
			ps.executeUpdate();
			return true;
		}catch (SQLIntegrityConstraintViolationException e) {
			m="";
		}
		catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}finally {
			if(con!=null)
				try {
					con.close();
				} catch (SQLException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
		}

		return false;
	}


	public int getGrp(int sGroup) {
		sql="select * FROM moshaver.subgroups where ID=?";


		try {
			Class.forName("com.mysql.cj.jdbc.Driver");
			Connection con= DriverManager.getConnection(url, user, password);
			PreparedStatement ps=con.prepareStatement(sql);
			ps.setInt(1, sGroup);
			ResultSet rs=ps.executeQuery();
			if (rs.next()) {
				return rs.getInt(2);
			}
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}

		return -1;
	}
	public String getGrpName(int Group) {
		sql="select * FROM moshaver.groups where ID=?";

		Connection con=null;
		try {
			Class.forName("com.mysql.cj.jdbc.Driver");
			con= DriverManager.getConnection(url, user, password);
			PreparedStatement ps=con.prepareStatement(sql);
			ps.setInt(1, Group);
			ResultSet rs=ps.executeQuery();
			if (rs.next()) {
				return rs.getString(2);
			}
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}finally {
			if(con!=null)
				try {
					con.close();
				} catch (SQLException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
		}

		return null;
	}
	public String getsGrpName(int sGroup) {
		sql="select * FROM moshaver.subgroups where ID=?";

		Connection con=null;
		try {
			Class.forName("com.mysql.cj.jdbc.Driver");
			con= DriverManager.getConnection(url, user, password);
			PreparedStatement ps=con.prepareStatement(sql);
			ps.setInt(1, sGroup);
			ResultSet rs=ps.executeQuery();
			if (rs.next()) {
				return rs.getString(3);
			}
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}finally {
			if(con!=null)
				try {
					con.close();
				} catch (SQLException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
		}

		return null;
	}
	public String getName(int id,String g) {
		sql="select * FROM "+g+" where ID=?";


		try {
			Class.forName("com.mysql.cj.jdbc.Driver");
			Connection con= DriverManager.getConnection(url, user, password);
			PreparedStatement ps=con.prepareStatement(sql);
			ps.setInt(1, id);
			ResultSet rs=ps.executeQuery();
			if (rs.next()) {
				return rs.getString("FName")+" "+rs.getString("LName");
			}
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}

		return null;
	}
	public boolean checkGrp(int moshaverId ,int grp) {
		sql="select * FROM moshaver.moshaver where ID=? and Groups_FK=?";


		try {
			Class.forName("com.mysql.cj.jdbc.Driver");
			Connection con= DriverManager.getConnection(url, user, password);
			PreparedStatement ps=con.prepareStatement(sql);
			ps.setInt(1, moshaverId);
			ps.setInt(2, grp);
			ResultSet rs=ps.executeQuery();
			if (rs.next()) {
				return false;
			}
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}

		return true;
	}

	public int maxIdGroup(String g) {
		sql="SELECT * FROM "+g+" ORDER BY ID DESC LIMIT 1";

		Connection con=null;
		try {
			Class.forName("com.mysql.cj.jdbc.Driver");
			con= DriverManager.getConnection(url, user, password);
			PreparedStatement ps=con.prepareStatement(sql);
			//	ps.setString(1, g);
			ResultSet rs=ps.executeQuery();
			if (rs.next()) {
				m=1+rs.getInt(1)+"";
				return rs.getInt(1);
			}
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}finally {
			if(con!=null)
				try {
					con.close();
				} catch (SQLException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
		}
		return 0;
	}
	public int getRowI(int r) {
		sql="SELECT * FROM moshaver.moshaver where MemberShip_FK=2 or MemberShip_FK=1 limit ?,1";

		Connection con=null;
		try {
			Class.forName("com.mysql.cj.jdbc.Driver");
			con= DriverManager.getConnection(url, user, password);
			PreparedStatement ps=con.prepareStatement(sql);
			ps.setInt(1, r);
			ResultSet rs=ps.executeQuery();
			if (rs.next()) {
				return rs.getInt(1);
			}
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}finally {
			if(con!=null)
				try {
					con.close();
				} catch (SQLException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
		}



		return -1;
	}
	public int getRowId(int r) {
		sql="SELECT * FROM moshaver.users limit ?,1";


		try {
			Class.forName("com.mysql.cj.jdbc.Driver");
			Connection con= DriverManager.getConnection(url, user, password);
			PreparedStatement ps=con.prepareStatement(sql);
			ps.setInt(1, r);
			ResultSet rs=ps.executeQuery();
			if (rs.next()) {
				return rs.getInt(1);
			}
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}

		return -1;
	}
	public String getmRow(int r) {
		sql="SELECT * FROM moshaver.moshaver where MemberShip_FK=2 or MemberShip_FK=1 limit ?,1";

		Connection con=null;
		try {
			Class.forName("com.mysql.cj.jdbc.Driver");
			con= DriverManager.getConnection(url, user, password);
			PreparedStatement ps=con.prepareStatement(sql);
			ps.setInt(1, r);
			ResultSet rs=ps.executeQuery();
			if (rs.next()) {
				return rs.getString(4)+" "+rs.getString(5)+"("+rs.getDouble(11)+" از 5)";
			}
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}finally {
			if(con!=null)
				try {
					con.close();
				} catch (SQLException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
		}

		return null;
	}
	public String getuRow(int r) {
		sql="SELECT * FROM moshaver.users limit ?,1";

		Connection con=null;
		try {
			Class.forName("com.mysql.cj.jdbc.Driver");
			con= DriverManager.getConnection(url, user, password);
			PreparedStatement ps=con.prepareStatement(sql);
			ps.setInt(1, r);
			ResultSet rs=ps.executeQuery();
			if (rs.next()) {
				return rs.getString(4)+" "+rs.getString(5);
			}
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}finally {
			if(con!=null)
				try {
					con.close();
				} catch (SQLException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
		}

		return null;
	}


}
