package com.ali.moshaver;

import java.io.IOException;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import com.ali.dao.DataCon;

/**
 * Servlet implementation class delMoshaver
 */
@WebServlet("/DelDarkhast")
public class delDarkhast extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		int id=Integer.parseInt(request.getParameter("key"));
		DataCon dc=new DataCon();
		HttpSession hs=request.getSession();
		if (dc.delId("moshaver.darkhast", id)) {
			hs.setAttribute("msg", "درخواست مورد نظر حذف شد.");
			if (request.getParameter("ism")==null) {
				response.sendRedirect("HDarkhast.jsp");
			}else {
				response.sendRedirect("HMDarkhast.jsp");

			}
			
		}
		else {
			hs.setAttribute("msg", "مشکلی به وجود آمده.");
			if (request.getParameter("ism")==null) {
				response.sendRedirect("HDarkhast.jsp");
			}else {
				response.sendRedirect("HMDarkhast.jsp");

			}
		}
	}
	

}
