package com.ali.moshaver;

import java.io.IOException;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import com.ali.dao.DataCon;

/**
 * Servlet implementation class delMoshaver
 */
@WebServlet("/delPasokh")
public class delPasokh extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		int id=Integer.parseInt(request.getParameter("key"));
		int del=Integer.parseInt(request.getParameter("dl"));

		DataCon dc=new DataCon();
		HttpSession hs=request.getSession();
		if (del!=1&&dc.cancelPasokh(id)) {
			hs.setAttribute("msg", "پاسخ مورد نظر لغو شد.");

			response.sendRedirect("lPasokh.jsp");
		}else if (del==1&&dc.delId("moshaver.respond", id)) {
			hs.setAttribute("msg", "پاسخ مورد نظر حذف شد.");

			response.sendRedirect("lMPasokh.jsp");
		}
		else {
			hs.setAttribute("msg", "مشکلی به وجود آمده.");
			if (del==1) {
				response.sendRedirect("lMPasokh.jsp");
			}else {
			response.sendRedirect("lPasokh.jsp");
			}
		}
	}
	

}
