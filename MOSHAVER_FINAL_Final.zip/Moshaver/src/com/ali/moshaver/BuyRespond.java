package com.ali.moshaver;

import java.io.IOException;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import com.ali.dao.DataCon;

/**
 * Servlet implementation class BuyRespond
 */
@WebServlet("/BuyRespond")
public class BuyRespond extends HttpServlet {

	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub

		HttpSession hs=request.getSession();
		request.setCharacterEncoding("utf-8");
		int mid=0;
		if (request.getParameter("MID")!=null) {
			mid=Integer.parseInt(request.getParameter("MID"));
		}
		char isp='n';
		if (request.getParameter("isP")!=null) {
			isp='t';
		}
		int uid=Integer.parseInt(request.getParameter("UID"));
		int did=Integer.parseInt(request.getParameter("DID"));
		int pid=Integer.parseInt(request.getParameter("PID"));
		String Cst=request.getParameter("cost");
		DataCon dc=new DataCon();
		if (dc.getpyWlt(uid, Cst, mid)) {

			if (isp=='t') {
				if (dc.payCPasokh(pid,Integer.parseInt(Cst))) {
					hs.setAttribute("msg3", "هزینه مشاوره پرداخت شد.");
					hs.setAttribute("wltu", dc.getWlt());
					response.sendRedirect("done.jsp");
				}
				else {
					hs.setAttribute("msg", "روند پرداخت با مشکل مواجه شد.");
					response.sendRedirect("buy.jsp");
				}
			}
			else if (dc.cloneRes(uid, did, pid)) {
				hs.setAttribute("msg3", "پاسخ به میزکار(پاسخ ها) شما افزوده شد.");
				hs.setAttribute("wltu", dc.getWlt());
				response.sendRedirect("done.jsp");
			}
			else {
				hs.setAttribute("msg", "روند پرداخت با مشکل مواجه شد.");
				response.sendRedirect("buy.jsp");
			}
		}else {
			hs.setAttribute("msg", dc.msg());
			response.sendRedirect("buy.jsp");

		}
	}

}
