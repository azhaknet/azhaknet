package com.ali.moshaver;

import java.io.IOException;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import com.ali.dao.DataCon;

import javafx.scene.chart.PieChart.Data;

/**
 * Servlet implementation class EditProfile
 */
@WebServlet("/EditProfile")
public class EditProfile extends HttpServlet {

	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		HttpSession hs=request.getSession();
		request.setCharacterEncoding("utf-8");
		String isu=request.getParameter("isu");
		int id=Integer.parseInt(request.getParameter("key"));
		String name=request.getParameter("mname");
		String lname=request.getParameter("mlname");
		String tell=request.getParameter("mphone");
		String email=request.getParameter("memail");
		String pass=request.getParameter("mpass");
		String rpass=request.getParameter("mrpass");
		DataCon dc=new DataCon();
		if (isu.equals("0")) {
			String madrak=request.getParameter("mmadrak");
			if (pass==null) {
				if (dc.updateMoshaver(id,  name, lname, tell, email,"", madrak)) {
					response.sendRedirect("done.jsp");
				}else {
					hs.setAttribute("msg", "مشکلی به وجود آمده");
					response.sendRedirect("EditMProfile.jsp");}

			}else if (pass.equals(rpass)) {
				if (dc.updateMoshaver(id, name, lname, tell, email,pass, madrak)) {
					response.sendRedirect("done.jsp");
				}else {
					hs.setAttribute("msg", "مشکلی به وجود آمده");
					response.sendRedirect("EditMProfile.jsp");}
			}else {
				hs.setAttribute("msg", "رمز و تکرار آن یکسان نمی باشند");
				response.sendRedirect("EditMProfile.jsp");
			}

		}else {
			if (pass==null) {
				
				if (dc.updateUser(id, name, lname, tell, email, "")) {
					response.sendRedirect("done.jsp");
				}else {
					hs.setAttribute("msg", "مشکلی به وجود آمده");
					response.sendRedirect("EditUProfile.jsp");}

			}else if (pass.equals(rpass)) {
				
				if (dc.updateUser(id, name, lname, tell, email, pass)) {
					response.sendRedirect("done.jsp");
				}else {
					hs.setAttribute("msg", "مشکلی به وجود آمده");
					response.sendRedirect("EditUProfile.jsp");}

			}else {
				
				hs.setAttribute("msg", "رمز و تکرار آن یکسان نمی باشند");
				response.sendRedirect("EditUProfile.jsp");
			}

		}

	}
}
