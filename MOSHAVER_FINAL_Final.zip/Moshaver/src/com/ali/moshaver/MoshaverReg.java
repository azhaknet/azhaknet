package com.ali.moshaver;

import java.io.IOException;

import com.ali.dao.DataCon;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

/**
 * Servlet implementation class MoshaverReg
 */
@WebServlet("/moshaverReg")
public class MoshaverReg extends HttpServlet {
	private static final long serialVersionUID = 1L;

	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		request.setCharacterEncoding("utf-8");
		int group = Integer.parseInt(request.getParameter("browser"));

		String FName=request.getParameter("mname");

		String LName=request.getParameter("mlname");
		String Tell = request.getParameter("mphone");

		String email=request.getParameter("memail");
		String madrak=request.getParameter("mmadrak");
		double score=0;
		String rpass=request.getParameter("mrpass");

		String UName=request.getParameter("muName");
		String pass=request.getParameter("mpass");
		DataCon dc=new DataCon();
		HttpSession hs=request.getSession();

		if (pass.equals(rpass)) {

			if (dc.addMoshaver(group, FName, LName, Tell, email, UName, pass, madrak, score)) {
				
				hs.setAttribute("msg3", "مشاور گرامی لطفا منتظر تایید مدیریت سایت بمانید.");
				response.sendRedirect("Registered.jsp");
			}
			else {
				hs.setAttribute("msg", "این نام کاربری قبلا انتخاب شده است.");
				response.sendRedirect("smoshaver.jsp");

			}
		} else {
				hs.setAttribute("msg", "رمز و تکرار آن یکسان نمی باشند");
				response.sendRedirect("smoshaver.jsp");}
	}

}
