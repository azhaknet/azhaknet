package com.ali.moshaver;

import java.io.IOException;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import com.ali.dao.DataCon;

/**
 * Servlet implementation class SPasokh
 */
@WebServlet("/SPasokh")
public class SPasokh extends HttpServlet {
	private static final long serialVersionUID = 1L;

	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub

		HttpSession hs=request.getSession();
		request.setCharacterEncoding("utf-8");
		DataCon dc=new DataCon();

		int Type=Integer.parseInt(request.getParameter("pType"));
		int Moshaver = (int) hs.getAttribute("mid");
		int cost=0;
		String Content=request.getParameter("Ptext");
		if (Type!=1) {
			cost=Integer.parseInt(request.getParameter("cost"));
			String messg="تلفنی";
			if (Type==3) {
				messg="واتساپ";
			}else if (Type==4) {
				messg="تلگرام";
				Type=3;
			}else if (Type==5) {
				messg="سروش";
				Type=3;
			}
			if (request.getParameter("SID")!=null && request.getParameter("SEmail")!=null ) {
				Content=" راه ارتباطی:"+messg+"&nbsp&nbsp&nbsp| \n"+"&nbspمدت مشاوره:"+request.getParameter("pDuration")+"&nbsp&nbsp&nbsp| \n"+"&nbspتاریخ شروع مشاوره:"+request.getParameter("pDate")+"&nbsp&nbsp&nbsp| \n"+"&nbspزمان شروع مشاوره:"+request.getParameter("pTime")+"&nbsp&nbsp&nbsp| \n"+"&nbspشماره تلفن همراه مشاور:"+dc.getMNumber(Moshaver)+"&nbsp&nbsp&nbsp| \n"+"&nbspآدرس ایمیل مشاور:"+dc.getMEmail(Moshaver)+"&nbsp&nbsp&nbsp| \n \n"+"&nbspتوضیحات بیشتر: \n"+request.getParameter("Ptext");
			}else if (request.getParameter("SID")!=null) {
				Content=" راه ارتباطی:"+messg+"&nbsp&nbsp&nbsp| \n"+"&nbspمدت مشاوره:"+request.getParameter("pDuration")+"&nbsp&nbsp&nbsp| \n"+"&nbspتاریخ شروع مشاوره:"+request.getParameter("pDate")+"&nbsp&nbsp&nbsp| \n"+"&nbspزمان شروع مشاوره:"+request.getParameter("pTime")+"&nbsp&nbsp&nbsp| \n"+"&nbspشماره تلفن همراه مشاور:"+dc.getMNumber(Moshaver)+"&nbsp&nbsp&nbsp| \n \n"+"&nbspتوضیحات بیشتر: \n"+request.getParameter("Ptext");
			}else if (request.getParameter("SEmail")!=null) {
				Content=" راه ارتباطی:"+messg+"&nbsp&nbsp&nbsp| \n"+"&nbspمدت مشاوره:"+request.getParameter("pDuration")+"&nbsp&nbsp&nbsp| \n"+"&nbspتاریخ شروع مشاوره:"+request.getParameter("pDate")+"&nbsp&nbsp&nbsp| \n"+"&nbspزمان شروع مشاوره:"+request.getParameter("pTime")+"&nbsp&nbsp&nbsp| \n"+"&nbspآدرس ایمیل مشاور:"+dc.getMEmail(Moshaver)+"&nbsp&nbsp&nbsp| \n \n"+"&nbspتوضیحات بیشتر: \n"+request.getParameter("Ptext");
			}else {
				Content=" راه ارتباطی:"+messg+"&nbsp&nbsp&nbsp| \n"+"&nbspمدت مشاوره:"+request.getParameter("pDuration")+"&nbsp&nbsp&nbsp| \n"+"&nbspتاریخ شروع مشاوره:"+request.getParameter("pDate")+"&nbsp&nbsp&nbsp| \n"+"&nbspزمان شروع مشاوره:"+request.getParameter("pTime")+"&nbsp&nbsp&nbsp| \n"+"&nbspتوضیحات بیشتر:"+request.getParameter("Ptext");
			}
			
		}
		int darkhast=Integer.parseInt(request.getParameter("Did"));
		
		if (dc.addPasokh(Moshaver, darkhast,Type,cost, Content)) {
			hs.setAttribute("msg3", "کد پاسخ: "+dc.msg());
			response.sendRedirect("done.jsp");

		}else { 
			hs.setAttribute("msg2", "مشکلی به وجود آمده است");
			if (Type==1)
				response.sendRedirect("fDarkhast.jsp");
			else
				response.sendRedirect("respond.jsp");
		}

	}

}
