package com.ali.moshaver;

import java.io.IOException;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import com.ali.dao.DataCon;

/**
 * Servlet implementation class TaidMoshaver
 */
@WebServlet("/TaidMoshaver")
public class TaidMoshaver extends HttpServlet {
	private static final long serialVersionUID = 1L;
      
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		int id=Integer.parseInt(request.getParameter("key"));
		DataCon dc=new DataCon();
		HttpSession hs=request.getSession();
		if (dc.approvalMoshaver(2, id)) {
			hs.setAttribute("msg", "مشاور مورد نظر تایید شد.");

			response.sendRedirect("TMoshaver.jsp");
		}
		else {
			hs.setAttribute("msg", "مشکلی به وجود آمده.");
			response.sendRedirect("TMoshaver.jsp");
		}
	}
}
