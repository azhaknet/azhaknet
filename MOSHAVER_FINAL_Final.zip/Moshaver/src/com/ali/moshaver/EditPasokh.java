package com.ali.moshaver;

import java.io.IOException;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import com.ali.dao.DataCon;

/**
 * Servlet implementation class SPasokh
 */
@WebServlet("/EditPasokh")
public class EditPasokh extends HttpServlet {
	private static final long serialVersionUID = 1L;
	@Override
		protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
			// TODO Auto-generated method stub
		HttpSession hs=request.getSession();
		request.setCharacterEncoding("utf-8");
		int id = Integer.parseInt(request.getParameter("key"));
		String sd=request.getParameter("lch");
		String txt=request.getParameter("Ptext");
		DataCon dc=new DataCon();
		
		if (dc.edFPasokh(id, txt)) {
			
			hs.setAttribute("msg3", "پاسخ ویرایش گردید.");
			if (sd!=null) {
				if (dc.setSRes(id)) {
					hs.setAttribute("msg3", "پاسخ  به عنوان خلاصه مشاوره ویرایش گردید.");
					response.sendRedirect("done.jsp");
				}else {
				
				response.sendRedirect("done.jsp");
				}
			}else {
				response.sendRedirect("done.jsp");
			}
				
		
		}else { 
			hs.setAttribute("msg2", "مشکلی به وجود آمده است");
			response.sendRedirect("editRes.jsp");}
	
		}
   

}
