package com.ali.moshaver;

import java.io.IOException;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import com.ali.dao.DataCon;

/**
 * Servlet implementation class delMoshaver
 */
@WebServlet("/delUser")
public class delUser extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		int id=Integer.parseInt(request.getParameter("key"));
		DataCon dc=new DataCon();
		HttpSession hs=request.getSession();
		if (dc.delId("moshaver.users", id)) {
			hs.setAttribute("msg", "کاربر مورد نظر حذف شد.");

			response.sendRedirect("MUser.jsp");
		}
		else {
			hs.setAttribute("msg", "مشکلی به وجود آمده.");
			response.sendRedirect("MUser.jsp");
		}
	}
	

}
