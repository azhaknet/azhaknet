package com.ali.moshaver;

import java.io.IOException;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import com.ali.dao.DataCon;

/**
 * Servlet implementation class UserReg
 */
@WebServlet("/userReg")
public class UserReg extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		HttpSession hs=request.getSession();
		request.setCharacterEncoding("utf-8");

		String FName=request.getParameter("uname");

		String LName=request.getParameter("ulname");
		String Tell = request.getParameter("uphone");
		int age = Integer.parseInt(request.getParameter("uage"));

		String email=request.getParameter("uemail");
		String rpass=request.getParameter("urpass");

		String UName=request.getParameter("uuName");
		String pass=request.getParameter("upass");
		DataCon dc=new DataCon();

		if (pass.equals(rpass)) {

			if (dc.addUser(UName, pass, FName, LName, Tell, email, age)) {
				hs.setAttribute("msg3", "کاربر گرامی حساب کاربری شما فعال شد.");
				response.sendRedirect("Registered.jsp");
			}
			else {
				hs.setAttribute("msg", "مشکلی به وجود آمده(این نام کاربری قبلا انتخاب شده است");
				response.sendRedirect("suser.jsp");

			}
		} else {
			hs.setAttribute("msg", "رمز و تکرار آن یکسان نمی باشند");
			response.sendRedirect("suser.jsp");}
	}
		
	
	

}
