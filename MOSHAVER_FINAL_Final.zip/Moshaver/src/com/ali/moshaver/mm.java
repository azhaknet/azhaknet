package com.ali.moshaver;

import java.io.IOException;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import com.ali.dao.DataCon;

/**
 * Servlet implementation class mm
 */
@WebServlet("/mm")
public class mm extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public mm() {
        super();
        // TODO Auto-generated constructor stub
    }
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		HttpSession hs=request.getSession();
		request.setCharacterEncoding("utf-8");
		int id=Integer.parseInt(request.getParameter("id1"));
		String pm=request.getParameter("pMny");
		DataCon dc=new DataCon();
		if (pm!=null) {
			String f=dc.getnWltu(id, pm);
			if (dc.chargeWallet(id, f)) {
				hs.setAttribute("msg3", "حساب شما شارژ شد.");
				hs.setAttribute("wltu", f);
				response.sendRedirect("done.jsp");
			}
			else {
				hs.setAttribute("msg", "روند پرداخت با مشکل مواجه شد.");
				response.sendRedirect("charge.jsp");
			
			}
		}else {
			
			if (dc.dechargeWallet(id,"0")) {
				hs.setAttribute("msg3", "مبلغ کیف پول به حساب شما واریز شد.");
				hs.setAttribute("wlt", "0");
				response.sendRedirect("done.jsp");
			}
			else {
				hs.setAttribute("msg", "روند برداشت با مشکل مواجه شد.");
				response.sendRedirect("charge.jsp");
			
			}
		}
	}

}
