package com.ali.moshaver;

import java.io.IOException;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import com.ali.dao.DataCon;

/**
 * Servlet implementation class LoginServ
 */
@WebServlet("/login")
public class LoginServ extends HttpServlet {
	private static final long serialVersionUID = 1L;

	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		request.setCharacterEncoding("utf-8");
		DataCon dc=new DataCon();
		String UName=request.getParameter("luName");
		String pass=request.getParameter("lpass");
		String sd=request.getParameter("lch");
		HttpSession group=request.getSession();
		for (int i = 1; i <= dc.maxIdGroup("moshaver.groups"); i++) {
			group.setAttribute("grp"+i, dc.getGrpName(i));
		}
		for (int i = 1; i <= dc.maxIdGroup("moshaver.subgroups"); i++) {
			group.setAttribute("sgrp"+i, dc.getsGrpName(i));
		}
		
		int im=0;
		int iim=1;
		while (iim!=dc.maxIdGroup("moshaver.moshaver") && iim!=-1) {
			iim=dc.getRowI(im);
			group.setAttribute("msvr"+iim, dc.getmRow(im));
			group.setAttribute("Mn"+iim, dc.getRes(iim));
			im++;
		}

		int iu=0;
		int iiu=1;
		while (iiu!=dc.maxIdGroup("moshaver.users")&& iiu!=-1) {
			iiu=dc.getRowId(iu);
			group.setAttribute("user"+iiu, dc.getuRow(iu));
			group.setAttribute("Dn"+iiu, dc.getDar(iiu));
			iu++;
		}

		HttpSession hs=request.getSession();
		if (sd!=null) {
			if (dc.checkAdmin(UName, pass)) {
				hs.setAttribute("mid", 1);
				hs.setAttribute("wlt", dc.getWlt());
				hs.setAttribute("n1", UName);
				response.sendRedirect("admin_pishkhan.jsp");
			}
			else if (dc.checkMoshaver(UName, pass)==1) {
				hs.setAttribute("mid", dc.getCoId());
				hs.setAttribute("wlt", dc.getWlt());
				hs.setAttribute("n1", UName);

				response.sendRedirect("moshaver_pishkhan.jsp");

			}
			else if (dc.checkMoshaver(UName, pass)==0) {
				hs.setAttribute("msg", "مشاور گرامی مدیریت در حال بررسی اطلاعات شما می باشد</br>&nbsp لطفا منتظر بمانید...");

				response.sendRedirect("login.jsp");

			}
			else {
				hs.setAttribute("msg", "نام کاربری یا رمز شما اشتباه است");
				response.sendRedirect("login.jsp");

			}
		}
		else if (dc.checkUser(UName, pass)) {
			hs.setAttribute("n1", UName);
			hs.setAttribute("uid", dc.getCoId());
			hs.setAttribute("wltu", dc.getWlt());
			group.setAttribute("UserName", dc.getName(dc.getCoId(), "moshaver.users"));


			response.sendRedirect("user_pishkhan.jsp");

		}
		else {
			hs.setAttribute("msg", "نام کاربری یا رمز شما اشتباه است");
			response.sendRedirect("login.jsp");

		}
	}

}
