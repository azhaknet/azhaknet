package com.ali.moshaver;

import java.io.IOException;
import java.net.URL;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import org.apache.jasper.tagplugins.jstl.core.Url;

import com.ali.dao.DataCon;

/**
 * Servlet implementation class SDarkhast
 */
@WebServlet("/SDarkhast")
public class SDarkhast extends HttpServlet {
	private static final long serialVersionUID = 1L;

	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub

		HttpSession hs=request.getSession();
		request.setCharacterEncoding("utf-8");
		String mvr=request.getParameter("answer");
		int sgroup = Integer.parseInt(request.getParameter("dgroup"));

		String Title=request.getParameter("dTitle");

		String Content=request.getParameter("DText");
		int User = (int) hs.getAttribute("uid");
		
		int m1=mvr.indexOf("(");
		int m2=mvr.indexOf(")");
		
		int moshaver=Integer.parseInt(mvr.substring(m1+1, m2));
		

		DataCon dc=new DataCon();
		if (moshaver==0&&dc.addFDarkhast(User, Title, Content, sgroup)) {
			hs.setAttribute("msg3", "کد پیگیری درخواست: "+dc.msg());
			response.sendRedirect("done.jsp");
		}
		else if(dc.checkGrp(moshaver, dc.getGrp(sgroup))) {
			hs.setAttribute("msg2", "مشاور مورد نظر در این گروه فعالیت نمی کند.");
			response.sendRedirect("sendDarkhast.jsp");
		}else if (dc.addDarkhast(User, moshaver, Title, Content, sgroup)&& moshaver!=0) {

			hs.setAttribute("msg3", "کد پیگیری درخواست: "+dc.msg());
			response.sendRedirect("done.jsp");

		}else { 
			hs.setAttribute("msg2", "مشکلی به وجود آمده است");
			response.sendRedirect("sendDarkhast.jsp");}
	}


}
